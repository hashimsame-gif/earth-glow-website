SKIN MIMIC CARE image assets

Upload these files into an /assets folder in your GitHub repository.
Use relative paths such as /assets/skinmimic-logo.png in your website.

Note: moor-mud-ritual-reference.jpg and salon-interior-reference.jpg are crops from reference screenshots, so they are low-resolution placeholders. Replace them with original high-resolution photography before public launch.
